# UART Logger

Initially created to allow logging of the P16 ADI RH UART chips debugging output.